// Highlight rows based on attendance percentage
document.addEventListener('DOMContentLoaded', () => {
    const rows = document.querySelectorAll('.attendance-table tbody tr');
    rows.forEach((row) => {
        const percentage = parseInt(row.children[3].textContent.replace('%', ''));
        const statusCell = row.children[4];
        if (percentage >= 90) {
            statusCell.textContent = 'Excellent';
            statusCell.style.color = '#00ffcc';
        } else if (percentage >= 75) {
            statusCell.textContent = 'Good';
            statusCell.style.color = '#28a745';
        } else if (percentage >= 50) {
            statusCell.textContent = 'Average';
            statusCell.style.color = '#ffc107';
        } else {
            statusCell.textContent = 'Poor';
            statusCell.style.color = '#dc3545';
        }
    });
});

// Handle login form submission
document.getElementById('loginForm')?.addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent the default form submission behavior

    // Simulate successful login
    alert('Login Successful!');
    window.location.href = 'dashboard.html'; // Redirect to the dashboard page
});
